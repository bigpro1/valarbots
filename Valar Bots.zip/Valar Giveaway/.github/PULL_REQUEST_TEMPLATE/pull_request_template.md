**Please describe the changes this PR makes and why it should be merged:**

<!--
Please move lines that apply to you out of the comment:
- Code changes have been tested against an actual instance of the bot, or there are no code changes
- This PR fixes an existing bug ( please include the issue ( if created on the repository ) / bug )
- This PR includes breaking changes ( features removed / additional utility functions added which may not be compatible with the earlier version of this repository )
- This PR **only** includes non-code changes, like changes to documentation, README, etc.
-->
