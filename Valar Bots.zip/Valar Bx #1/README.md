# light-music-bot
A super light, fast and simple tho advanced Music Bot, without any Music Manager Packages like Lavalink, discord-player or distube. Technically providing up to all filters of lavalink, but limited to 19 predefined ones, with speed and bassboost control, as well as everything in slash Commands and message Commands!

## Installation & Get Started

- 1. in the `./config/config.json` File paste your Token
- 2. in the `./index.js` adjust the SlashCommands Deployment Settings
  - *After deployed, globally once, disable it!*
- 3. Start the bot: `npm install` and then `node .`

## Hosting Requirements:

- **RAM:** 40-50mb on idle, + 15-20mb / Audio Connection (for more than 100+ Servers, 250mb Ram recommended)
- **CPU:** 2-8% of a 2ghz CORE on idle, 20% of a 2ghz Core, while fetching youtube, 30% of a 2ghz Core, while changing the FILTERS

## Support Server:

> https://discord.gg/milrato

## Credits

> *If you consider using this Bot, make sure to credit either this Repository or, Tomato#6966 on Discord or the Support Discord Server https://discord.gg/milrato. THANKS!*
